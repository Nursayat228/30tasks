#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;

namespace Task01
{
    class Animal { public virtual void Speak() => Console.WriteLine("Животное издаёт звук"); }
    class Dog : Animal { public override void Speak() => Console.WriteLine("Гав-гав!"); }
    class Cat : Animal { public override void Speak() => Console.WriteLine("Мяу!"); }
    static class T { public static void Run() { new Dog().Speak(); new Cat().Speak(); } }
}

namespace Task02
{
    class Vehicle
    {
        public string Brand { get; set; }
        public int Speed { get; set; }
        public Vehicle(string brand, int speed) { Brand = brand; Speed = speed; }
        public virtual void Info() => Console.WriteLine($"{Brand}, скорость {Speed} км/ч");
    }
    class Car : Vehicle
    {
        public int Doors { get; set; }
        public Car(string b, int s, int doors) : base(b, s) { Doors = doors; }
        public override void Info() { base.Info(); Console.WriteLine($"  Дверей: {Doors}"); }
    }
    class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }
        public Motorcycle(string b, int s, bool sidecar) : base(b, s) { HasSidecar = sidecar; }
        public override void Info() { base.Info(); Console.WriteLine($"  С коляской: {(HasSidecar ? "да" : "нет")}"); }
    }
    static class T { public static void Run() { new Car("Toyota", 180, 4).Info(); new Motorcycle("Ural", 110, true).Info(); } }
}

namespace Task03
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person(string name, int age) { Name = name; Age = age; }
        public virtual void Info() => Console.WriteLine($"Имя: {Name}, возраст: {Age}");
    }
    class Student : Person
    {
        public string Major { get; set; }
        public int Course { get; set; }
        public Student(string n, int a, string major, int course) : base(n, a) { Major = major; Course = course; }
        public override void Info() { base.Info(); Console.WriteLine($"Специальность: {Major}, курс: {Course}"); }
    }
    static class T { public static void Run() { new Student("Анна", 19, "Информатика", 2).Info(); } }
}

namespace Task04
{
    class Employee
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public Employee(string n, decimal s) { Name = n; Salary = s; }
        public virtual void Info() => Console.WriteLine($"{Name}, зарплата {Salary}");
    }
    class Manager : Employee
    {
        public int TeamSize { get; set; }
        public Manager(string n, decimal s, int team) : base(n, s) { TeamSize = team; }
        public override void Info() { base.Info(); Console.WriteLine($"  Размер команды: {TeamSize}"); }
    }
    class Developer : Employee
    {
        public string Language { get; set; }
        public Developer(string n, decimal s, string lang) : base(n, s) { Language = lang; }
        public override void Info() { base.Info(); Console.WriteLine($"  Язык: {Language}"); }
    }
    static class T { public static void Run() { new Manager("Ирина", 150000, 8).Info(); new Developer("Олег", 180000, "C#").Info(); } }
}

namespace Task05
{
    class Shape { public virtual double GetArea() => 0; }
    class Rectangle : Shape
    {
        public double W { get; set; } public double H { get; set; }
        public Rectangle(double w, double h) { W = w; H = h; }
        public override double GetArea() => W * H;
    }
    class Circle : Shape
    {
        public double R { get; set; }
        public Circle(double r) { R = r; }
        public override double GetArea() => Math.PI * R * R;
    }
    static class T
    {
        public static void Run()
        {
            Console.WriteLine($"Прямоугольник 3x4: {new Rectangle(3, 4).GetArea():F2}");
            Console.WriteLine($"Круг r=2: {new Circle(2).GetArea():F2}");
        }
    }
}

namespace Task06
{
    class Vehicle { public virtual void Move() => Console.WriteLine("Транспорт движется"); }
    class Car : Vehicle { public override void Move() => Console.WriteLine("Автомобиль едет по дороге"); }
    class Bus : Vehicle { public override void Move() => Console.WriteLine("Автобус едет по маршруту и делает остановки"); }
    class Train : Vehicle { public override void Move() => Console.WriteLine("Поезд идёт по рельсам"); }
    static class T { public static void Run() { foreach (Vehicle v in new Vehicle[] { new Car(), new Bus(), new Train() }) v.Move(); } }
}

namespace Task07
{
    class Worker
    {
        public string Name { get; set; }
        public string Position { get; set; }
        public Worker(string n, string p) { Name = n; Position = p; }
        public virtual void Work() => Console.WriteLine($"{Name} ({Position}) работает");
    }
    class Cashier : Worker
    {
        public Cashier(string n) : base(n, "Кассир") { }
        public override void Work() => Console.WriteLine($"{Name} ({Position}) пробивает покупки");
    }
    class Seller : Worker
    {
        public Seller(string n) : base(n, "Продавец") { }
        public override void Work() => Console.WriteLine($"{Name} ({Position}) консультирует покупателей");
    }
    static class T { public static void Run() { new Cashier("Мария").Work(); new Seller("Пётр").Work(); } }
}

namespace Task08
{
    class Computer
    {
        public string Processor { get; set; }
        public int RAM { get; set; }
        public Computer(string cpu, int ram) { Processor = cpu; RAM = ram; }
        public virtual void Info() => Console.WriteLine($"CPU: {Processor}, RAM: {RAM} ГБ");
    }
    class Laptop : Computer
    {
        public double BatteryHours { get; set; }
        public Laptop(string c, int r, double battery) : base(c, r) { BatteryHours = battery; }
        public override void Info() { base.Info(); Console.WriteLine($"  Автономность: {BatteryHours} ч"); }
    }
    class Desktop : Computer
    {
        public int PowerSupplyWatts { get; set; }
        public Desktop(string c, int r, int psu) : base(c, r) { PowerSupplyWatts = psu; }
        public override void Info() { base.Info(); Console.WriteLine($"  Блок питания: {PowerSupplyWatts} Вт"); }
    }
    static class T { public static void Run() { new Laptop("Intel i7", 16, 8.5).Info(); new Desktop("Ryzen 7", 32, 750).Info(); } }
}

namespace Task09
{
    class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public Book(string t, string a) { Title = t; Author = a; }
        public virtual void Info() => Console.WriteLine($"«{Title}», {Author}");
    }
    class PaperBook : Book
    {
        public int Pages { get; set; }
        public PaperBook(string t, string a, int pages) : base(t, a) { Pages = pages; }
        public override void Info() { base.Info(); Console.WriteLine($"  Страниц: {Pages}"); }
    }
    class EBook : Book
    {
        public double FileSizeMb { get; set; }
        public string Format { get; set; }
        public EBook(string t, string a, double size, string fmt) : base(t, a) { FileSizeMb = size; Format = fmt; }
        public override void Info() { base.Info(); Console.WriteLine($"  Формат: {Format}, размер: {FileSizeMb} МБ"); }
    }
    static class T { public static void Run() { new PaperBook("Война и мир", "Л. Толстой", 1225).Info(); new EBook("Мастер и Маргарита", "М. Булгаков", 2.4, "EPUB").Info(); } }
}

namespace Task10
{
    class Pet { public virtual void Eat() => Console.WriteLine("Питомец ест"); }
    class Dog : Pet { public override void Eat() => Console.WriteLine("Собака грызёт кость"); }
    class Cat : Pet { public override void Eat() => Console.WriteLine("Кошка лакает молоко"); }
    class Parrot : Pet { public override void Eat() => Console.WriteLine("Попугай клюёт семечки"); }
    static class T { public static void Run() { foreach (Pet p in new Pet[] { new Dog(), new Cat(), new Parrot() }) p.Eat(); } }
}

namespace Task11
{
    class BankAccount
    {
        public decimal Balance { get; protected set; }
        public BankAccount(decimal initial = 0) { Balance = initial; }
        public virtual void Deposit(decimal amount)
        {
            if (amount <= 0) { Console.WriteLine("Сумма должна быть положительной"); return; }
            Balance += amount;
            Console.WriteLine($"Пополнение +{amount}. Баланс: {Balance}");
        }
        public virtual bool Withdraw(decimal amount)
        {
            if (amount <= 0 || amount > Balance) { Console.WriteLine("Недостаточно средств"); return false; }
            Balance -= amount;
            Console.WriteLine($"Снятие -{amount}. Баланс: {Balance}");
            return true;
        }
    }
    class SavingsAccount : BankAccount
    {
        public decimal InterestRate { get; }
        public decimal MinBalance { get; }
        public SavingsAccount(decimal initial, decimal rate, decimal minBalance) : base(initial) { InterestRate = rate; MinBalance = minBalance; }
        public override bool Withdraw(decimal amount)
        {
            if (Balance - amount < MinBalance) { Console.WriteLine($"Нельзя опускаться ниже неснижаемого остатка {MinBalance}"); return false; }
            return base.Withdraw(amount);
        }
        public void AddInterest() { decimal i = Balance * InterestRate; Balance += i; Console.WriteLine($"Начислены проценты {i}. Баланс: {Balance}"); }
    }
    class CreditAccount : BankAccount
    {
        public decimal CreditLimit { get; }
        public CreditAccount(decimal initial, decimal limit) : base(initial) { CreditLimit = limit; }
        public override bool Withdraw(decimal amount)
        {
            if (amount <= 0 || Balance - amount < -CreditLimit) { Console.WriteLine("Превышен кредитный лимит"); return false; }
            Balance -= amount;
            Console.WriteLine($"Снятие -{amount}. Баланс: {Balance} (лимит {CreditLimit})");
            return true;
        }
    }
    static class T
    {
        public static void Run()
        {
            var s = new SavingsAccount(1000, 0.05m, 200);
            s.Deposit(500); s.Withdraw(1400); s.Withdraw(1200); s.AddInterest();
            var c = new CreditAccount(100, 500);
            c.Withdraw(500); c.Withdraw(200); c.Deposit(300);
        }
    }
}

namespace Task12
{
    class Transport
    {
        public string Name { get; set; }
        public Transport(string name) { Name = name; }
        public virtual double CalculateCost(double km, double weightKg) => 0;
    }
    class Car : Transport
    {
        public Car() : base("Легковой автомобиль") { }
        public override double CalculateCost(double km, double weightKg) => km * 15 + weightKg * 0.5;
    }
    class Truck : Transport
    {
        public Truck() : base("Грузовик") { }
        public override double CalculateCost(double km, double weightKg) => km * 40 + weightKg * 0.2;
    }
    class Bus : Transport
    {
        public Bus() : base("Автобус") { }
        public override double CalculateCost(double km, double weightKg) => km * 30 + 500;
    }
    static class T
    {
        public static void Run()
        {
            foreach (Transport t in new Transport[] { new Car(), new Truck(), new Bus() })
                Console.WriteLine($"{t.Name}: перевозка 100 км, 200 кг = {t.CalculateCost(100, 200):F2}");
        }
    }
}

namespace Task13
{
    class Employee
    {
        public string Name { get; set; }
        public Employee(string n) { Name = n; }
        public virtual decimal GetSalary() => 0;
    }
    class Programmer : Employee
    {
        public int LinesOfCode { get; set; }
        public Programmer(string n, int loc) : base(n) { LinesOfCode = loc; }
        public override decimal GetSalary() => 80000 + LinesOfCode * 2m;
    }
    class Designer : Employee
    {
        public int Projects { get; set; }
        public Designer(string n, int p) : base(n) { Projects = p; }
        public override decimal GetSalary() => 60000 + Projects * 8000m;
    }
    class Manager : Employee
    {
        public int TeamSize { get; set; }
        public Manager(string n, int t) : base(n) { TeamSize = t; }
        public override decimal GetSalary() => 100000 + TeamSize * 5000m;
    }
    static class T
    {
        public static void Run()
        {
            foreach (Employee e in new Employee[] { new Programmer("Олег", 5000), new Designer("Лена", 3), new Manager("Ирина", 6) })
                Console.WriteLine($"{e.Name}: {e.GetSalary()}");
        }
    }
}

namespace Task14
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person(string n, int a) { Name = n; Age = a; }
        public virtual void Info() => Console.WriteLine($"Имя: {Name}, возраст: {Age}");
    }
    class Student : Person
    {
        public string University { get; set; }
        public int Course { get; set; }
        public Student(string n, int a, string uni, int course) : base(n, a) { University = uni; Course = course; }
        public override void Info() { base.Info(); Console.WriteLine($"Вуз: {University}, курс: {Course}"); }
    }
    class GraduateStudent : Student
    {
        public string ThesisTopic { get; set; }
        public string Advisor { get; set; }
        public GraduateStudent(string n, int a, string uni, int course, string topic, string advisor) : base(n, a, uni, course)
        { ThesisTopic = topic; Advisor = advisor; }
        public override void Info() { base.Info(); Console.WriteLine($"Тема диссертации: {ThesisTopic}, научный руководитель: {Advisor}"); }
    }
    static class T { public static void Run() { new GraduateStudent("Дмитрий", 24, "МГУ", 2, "Нейронные сети", "проф. Иванов").Info(); } }
}

namespace Task15
{
    class MilitaryVehicle
    {
        public string Name { get; set; }
        public MilitaryVehicle(string n) { Name = n; }
        public virtual void Attack() => Console.WriteLine($"{Name} атакует");
    }
    class Tank : MilitaryVehicle
    {
        public Tank() : base("Танк") { }
        public override void Attack() => Console.WriteLine($"{Name} стреляет из орудия снарядом");
    }
    class Helicopter : MilitaryVehicle
    {
        public Helicopter() : base("Вертолёт") { }
        public override void Attack() => Console.WriteLine($"{Name} запускает управляемые ракеты");
    }
    class ArmoredCar : MilitaryVehicle
    {
        public ArmoredCar() : base("Бронеавтомобиль") { }
        public override void Attack() => Console.WriteLine($"{Name} ведёт огонь из пулемёта");
    }
    static class T { public static void Run() { foreach (MilitaryVehicle v in new MilitaryVehicle[] { new Tank(), new Helicopter(), new ArmoredCar() }) v.Attack(); } }
}

namespace Task16
{
    class Character
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int Damage { get; set; }
        public Character(string n, int h, int d) { Name = n; Health = h; Damage = d; }
        public virtual void Attack(Character target) { target.Health -= Damage; Console.WriteLine($"{Name} бьёт {target.Name} на {Damage}. HP цели: {target.Health}"); }
    }
    class Warrior : Character
    {
        public Warrior(string n) : base(n, 150, 20) { }
        public override void Attack(Character t) { Console.Write("[Мечом] "); base.Attack(t); }
    }
    class Mage : Character
    {
        public Mage(string n) : base(n, 80, 35) { }
        public override void Attack(Character t) { Console.Write("[Огненный шар] "); base.Attack(t); }
    }
    class Archer : Character
    {
        public Archer(string n) : base(n, 100, 25) { }
        public override void Attack(Character t) { Console.Write("[Стрела издалека] "); base.Attack(t); }
    }
    static class T
    {
        public static void Run()
        {
            var dummy = new Character("Манекен", 300, 0);
            new Warrior("Конан").Attack(dummy); new Mage("Мерлин").Attack(dummy); new Archer("Леголас").Attack(dummy);
        }
    }
}

namespace Task17
{
    class Device
    {
        public string Name { get; set; }
        public bool IsOn { get; protected set; }
        public Device(string n) { Name = n; }
        public virtual void TurnOn() { IsOn = true; Console.WriteLine($"{Name} включено"); }
        public virtual void TurnOff() { IsOn = false; Console.WriteLine($"{Name} выключено"); }
    }
    class Phone : Device
    {
        public Phone() : base("Телефон") { }
        public override void TurnOn() { base.TurnOn(); Console.WriteLine("  Загрузка Android..."); }
    }
    class Computer : Device
    {
        public Computer() : base("Компьютер") { }
        public override void TurnOn() { base.TurnOn(); Console.WriteLine("  Проверка BIOS, загрузка ОС..."); }
        public override void TurnOff() { Console.WriteLine("  Сохранение данных, завершение работы..."); base.TurnOff(); }
    }
    class Television : Device
    {
        public Television() : base("Телевизор") { }
        public override void TurnOn() { base.TurnOn(); Console.WriteLine("  Показывает 1-й канал"); }
    }
    static class T
    {
        public static void Run()
        {
            foreach (Device d in new Device[] { new Phone(), new Computer(), new Television() }) { d.TurnOn(); d.TurnOff(); }
        }
    }
}

namespace Task18
{
    class Payment { public virtual void Pay(double amount) => Console.WriteLine($"Платёж {amount:F2}"); }
    class CashPayment : Payment { public override void Pay(double amount) => Console.WriteLine($"Оплата наличными: {amount:F2}"); }
    class CardPayment : Payment
    {
        public string CardNumber { get; }
        public CardPayment(string number) { CardNumber = number; }
        public override void Pay(double amount) => Console.WriteLine($"Оплата картой **** {CardNumber[^4..]}: {amount:F2}");
    }
    class OnlinePayment : Payment
    {
        public string Email { get; }
        public OnlinePayment(string email) { Email = email; }
        public override void Pay(double amount) => Console.WriteLine($"Онлайн-оплата (чек на {Email}): {amount:F2}, комиссия {amount * 0.02:F2}");
    }
    static class T { public static void Run() { new CashPayment().Pay(500); new CardPayment("1234567812345678").Pay(1200); new OnlinePayment("a@mail.ru").Pay(999); } }
}

namespace Task19
{
    class Employee
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public virtual decimal BonusPercent => 0.05m;
        public Employee(string n, decimal s) { Name = n; Salary = s; }
        public decimal GetBonus() => Salary * BonusPercent;
        public decimal GetTotal() => Salary + GetBonus();
    }
    class Manager : Employee
    {
        public Manager(string n, decimal s) : base(n, s) { }
        public override decimal BonusPercent => 0.20m;
    }
    class Developer : Employee
    {
        public Developer(string n, decimal s) : base(n, s) { }
        public override decimal BonusPercent => 0.10m;
    }
    class SalesManager : Employee
    {
        public SalesManager(string n, decimal s) : base(n, s) { }
        public override decimal BonusPercent => 0.30m;
    }
    static class T
    {
        public static void Run()
        {
            foreach (Employee e in new Employee[] { new Manager("Ирина", 100000), new Developer("Олег", 120000), new SalesManager("Сергей", 80000) })
                Console.WriteLine($"{e.Name}: оклад {e.Salary}, бонус {e.BonusPercent:P0} = {e.GetBonus()}, итого {e.GetTotal()}");
        }
    }
}

namespace Task20
{
    class Animal
    {
        public string Name { get; set; }
        public Animal(string n) { Name = n; }
        public virtual void Eat() => Console.WriteLine($"{Name} ест");
        public virtual void MakeSound() => Console.WriteLine($"{Name} издаёт звук");
    }
    class Lion : Animal
    {
        public Lion() : base("Лев") { }
        public override void Eat() => Console.WriteLine("Лев ест мясо");
        public override void MakeSound() => Console.WriteLine("Лев: Р-р-рык!");
    }
    class Elephant : Animal
    {
        public Elephant() : base("Слон") { }
        public override void Eat() => Console.WriteLine("Слон ест траву и фрукты");
        public override void MakeSound() => Console.WriteLine("Слон: Тру-у-у!");
    }
    class Monkey : Animal
    {
        public Monkey() : base("Обезьяна") { }
        public override void Eat() => Console.WriteLine("Обезьяна ест бананы");
        public override void MakeSound() => Console.WriteLine("Обезьяна: У-у-а-а!");
    }
    class Snake : Animal
    {
        public Snake() : base("Змея") { }
        public override void Eat() => Console.WriteLine("Змея глотает мышей целиком");
        public override void MakeSound() => Console.WriteLine("Змея: Ш-ш-ш...");
    }
    class Penguin : Animal
    {
        public Penguin() : base("Пингвин") { }
        public override void Eat() => Console.WriteLine("Пингвин ест рыбу");
        public override void MakeSound() => Console.WriteLine("Пингвин: Кррра!");
    }
    static class T
    {
        public static void Run()
        {
            foreach (Animal a in new Animal[] { new Lion(), new Elephant(), new Monkey(), new Snake(), new Penguin() }) { a.Eat(); a.MakeSound(); }
        }
    }
}

namespace Task21
{
    abstract class Shape
    {
        public abstract double GetArea();
        public virtual void Print() => Console.WriteLine($"{GetType().Name}: площадь = {GetArea():F2}");
    }
    class Circle : Shape
    {
        public double R { get; }
        public Circle(double r) { R = r; }
        public override double GetArea() => Math.PI * R * R;
    }
    class Rectangle : Shape
    {
        public double W { get; } public double H { get; }
        public Rectangle(double w, double h) { W = w; H = h; }
        public override double GetArea() => W * H;
    }
    class Triangle : Shape
    {
        public double A { get; } public double B { get; } public double C { get; }
        public Triangle(double a, double b, double c) { A = a; B = b; C = c; }
        public override double GetArea()
        {
            double p = (A + B + C) / 2;
            return Math.Sqrt(p * (p - A) * (p - B) * (p - C));
        }
    }
    class Square : Shape
    {
        public double Side { get; }
        public Square(double s) { Side = s; }
        public override double GetArea() => Side * Side;
    }
    static class T
    {
        public static void Run()
        {
            var shapes = new List<Shape> { new Circle(2), new Rectangle(3, 4), new Triangle(3, 4, 5), new Square(5) };
            shapes.ForEach(s => s.Print());
        }
    }
}

namespace Task22
{
    class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public Product(string n, decimal p) { Name = n; Price = p; }
        public virtual decimal GetFinalPrice() => Price;
        public void Print() => Console.WriteLine($"{GetType().Name,-12} {Name,-18} базовая {Price,9} → итоговая {GetFinalPrice(),9:F2}");
    }
    class Electronics : Product
    {
        public int WarrantyMonths { get; set; }
        public Electronics(string n, decimal p, int warranty) : base(n, p) { WarrantyMonths = warranty; }
        public override decimal GetFinalPrice() => Price * 1.20m + Price * 0.01m * WarrantyMonths;
    }
    class Clothing : Product
    {
        public int DiscountPercent { get; set; }
        public Clothing(string n, decimal p, int discount) : base(n, p) { DiscountPercent = discount; }
        public override decimal GetFinalPrice() => Price * (100 - DiscountPercent) / 100m;
    }
    class Food : Product
    {
        public int DaysToExpire { get; set; }
        public Food(string n, decimal p, int days) : base(n, p) { DaysToExpire = days; }
        public override decimal GetFinalPrice() { decimal price = Price * 1.10m; return DaysToExpire <= 3 ? price * 0.5m : price; }
    }
    static class T
    {
        public static void Run()
        {
            var cart = new List<Product> { new Electronics("Наушники", 5000, 12), new Clothing("Куртка", 8000, 25), new Food("Йогурт", 100, 2) };
            cart.ForEach(p => p.Print());
            Console.WriteLine($"Итого: {cart.Sum(p => p.GetFinalPrice()):F2}");
        }
    }
}

namespace Task23
{
    abstract class Transport
    {
        public string Name { get; }
        protected Transport(string n) { Name = n; }
        public abstract void Move();
        public abstract double GetFuelConsumption();
    }
    class Car : Transport
    {
        public Car() : base("Легковой автомобиль") { }
        public override void Move() => Console.WriteLine($"{Name} едет по шоссе");
        public override double GetFuelConsumption() => 8.0;
    }
    class Truck : Transport
    {
        public Truck() : base("Грузовик") { }
        public override void Move() => Console.WriteLine($"{Name} везёт груз");
        public override double GetFuelConsumption() => 28.5;
    }
    class Bus : Transport
    {
        public Bus() : base("Автобус") { }
        public override void Move() => Console.WriteLine($"{Name} едет по маршруту");
        public override double GetFuelConsumption() => 22.0;
    }
    class Motorcycle : Transport
    {
        public Motorcycle() : base("Мотоцикл") { }
        public override void Move() => Console.WriteLine($"{Name} мчится по дороге");
        public override double GetFuelConsumption() => 4.5;
    }
    static class T
    {
        public static void Run()
        {
            foreach (Transport t in new Transport[] { new Car(), new Truck(), new Bus(), new Motorcycle() })
            { t.Move(); Console.WriteLine($"  Расход: {t.GetFuelConsumption()} л/100 км"); }
        }
    }
}

namespace Task24
{
    class MedicalWorker
    {
        public string Name { get; set; }
        public MedicalWorker(string n) { Name = n; }
        public virtual void Work() => Console.WriteLine($"{Name} работает в больнице");
    }
    class Doctor : MedicalWorker
    {
        public Doctor(string n) : base(n) { }
        public override void Work() => Console.WriteLine($"Врач {Name} осматривает пациента и ставит диагноз");
    }
    class Nurse : MedicalWorker
    {
        public Nurse(string n) : base(n) { }
        public override void Work() => Console.WriteLine($"Медсестра {Name} делает уколы и измеряет давление");
    }
    class Surgeon : MedicalWorker
    {
        public Surgeon(string n) : base(n) { }
        public override void Work() => Console.WriteLine($"Хирург {Name} проводит операцию");
    }
    static class T { public static void Run() { foreach (MedicalWorker w in new MedicalWorker[] { new Doctor("Петров"), new Nurse("Сидорова"), new Surgeon("Иванов") }) w.Work(); } }
}

namespace Task25
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person(string n, int a) { Name = n; Age = a; }
        public virtual void Introduce() => Console.WriteLine($"Я {Name}, мне {Age} лет.");
    }
    class Employee : Person
    {
        public string Position { get; set; }
        public decimal Salary { get; set; }
        public Employee(string n, int a, string pos, decimal salary) : base(n, a) { Position = pos; Salary = salary; }
        public void Work() => Console.WriteLine($"{Name} работает в должности «{Position}».");
        public override void Introduce() { base.Introduce(); Console.WriteLine($"  Должность: {Position}, зарплата: {Salary}"); }
    }
    class Manager : Employee
    {
        public int TeamSize { get; set; }
        public string Department { get; set; }
        public Manager(string n, int a, string pos, decimal salary, int team, string dep) : base(n, a, pos, salary) { TeamSize = team; Department = dep; }
        public void HoldMeeting() => Console.WriteLine($"{Name} проводит планёрку с командой из {TeamSize} чел. (отдел «{Department}»).");
        public override void Introduce() { base.Introduce(); Console.WriteLine($"  Отдел: {Department}, подчинённых: {TeamSize}"); }
    }
    class Director : Manager
    {
        public decimal Budget { get; set; }
        public int DepartmentsCount { get; set; }
        public Director(string n, int a, string pos, decimal salary, int team, string dep, decimal budget, int deps)
            : base(n, a, pos, salary, team, dep) { Budget = budget; DepartmentsCount = deps; }
        public void ApproveBudget() => Console.WriteLine($"{Name} утверждает бюджет {Budget} на {DepartmentsCount} отделов.");
        public override void Introduce() { base.Introduce(); Console.WriteLine($"  Бюджет: {Budget}, отделов: {DepartmentsCount}"); }
    }
    static class T
    {
        public static void Run()
        {
            var d = new Director("Алексей", 45, "Генеральный директор", 500000, 40, "Управление", 20_000_000m, 5);
            d.Introduce(); d.Work(); d.HoldMeeting(); d.ApproveBudget();
        }
    }
}

namespace Task26
{
    abstract class Character
    {
        public string Name { get; }
        public int Health { get; protected set; }
        protected Character(string n, int hp) { Name = n; Health = hp; }
        public abstract void Attack(Character target);
        public abstract void Defend();
        public abstract void SpecialAttack(Character target);
        public virtual void TakeDamage(int dmg) { Health = Math.Max(0, Health - dmg); Console.WriteLine($"  {Name} получает {dmg} урона, HP: {Health}"); }
    }
    class Warrior : Character
    {
        public Warrior(string n) : base(n, 150) { }
        public override void Attack(Character t) { Console.WriteLine($"{Name} рубит мечом {t.Name}"); t.TakeDamage(20); }
        public override void Defend() => Console.WriteLine($"{Name} поднимает щит");
        public override void SpecialAttack(Character t) { Console.WriteLine($"{Name} использует «Мощный удар»!"); t.TakeDamage(50); }
    }
    class Mage : Character
    {
        public Mage(string n) : base(n, 80) { }
        public override void Attack(Character t) { Console.WriteLine($"{Name} бросает искру в {t.Name}"); t.TakeDamage(25); }
        public override void Defend() => Console.WriteLine($"{Name} создаёт магический барьер");
        public override void SpecialAttack(Character t) { Console.WriteLine($"{Name} призывает «Метеорит»!"); t.TakeDamage(70); }
    }
    class Archer : Character
    {
        public Archer(string n) : base(n, 100) { }
        public override void Attack(Character t) { Console.WriteLine($"{Name} стреляет в {t.Name}"); t.TakeDamage(22); }
        public override void Defend() => Console.WriteLine($"{Name} уклоняется от удара");
        public override void SpecialAttack(Character t) { Console.WriteLine($"{Name} выпускает «Град стрел»!"); t.TakeDamage(45); }
    }
    static class T
    {
        public static void Run()
        {
            Character w = new Warrior("Конан"), m = new Mage("Мерлин"), a = new Archer("Леголас");
            w.Attack(m); m.Defend(); m.SpecialAttack(a); a.SpecialAttack(w);
        }
    }
}

namespace Task27
{
    class File
    {
        public string Name { get; set; }
        public double SizeKb { get; set; }
        public File(string n, double s) { Name = n; SizeKb = s; }
        public virtual void Open() => Console.WriteLine($"Открыт файл {Name} ({SizeKb} КБ)");
    }
    class TextFile : File
    {
        public TextFile(string n, double s) : base(n, s) { }
        public override void Open() => Console.WriteLine($"Текстовый редактор: открыт {Name} ({SizeKb} КБ)");
    }
    class ImageFile : File
    {
        public int Width { get; set; } public int Height { get; set; }
        public ImageFile(string n, double s, int w, int h) : base(n, s) { Width = w; Height = h; }
        public override void Open() => Console.WriteLine($"Просмотр изображения: {Name}, {Width}x{Height}");
    }
    class VideoFile : File
    {
        public TimeSpan Duration { get; set; }
        public VideoFile(string n, double s, TimeSpan d) : base(n, s) { Duration = d; }
        public override void Open() => Console.WriteLine($"Видеоплеер: {Name}, длительность {Duration}");
    }
    static class T
    {
        public static void Run()
        {
            var files = new List<File> { new TextFile("notes.txt", 12), new ImageFile("photo.jpg", 2048, 1920, 1080), new VideoFile("movie.mp4", 700000, TimeSpan.FromMinutes(95)) };
            files.ForEach(f => f.Open());
        }
    }
}

namespace Task28
{
    abstract class Employee
    {
        public string Name { get; }
        protected Employee(string n) { Name = n; }
        public abstract decimal CalculateSalary();
    }
    class HourlyEmployee : Employee
    {
        public decimal HourlyRate { get; } public int Hours { get; }
        public HourlyEmployee(string n, decimal rate, int hours) : base(n) { HourlyRate = rate; Hours = hours; }
        public override decimal CalculateSalary() => Hours <= 160 ? HourlyRate * Hours : HourlyRate * 160 + HourlyRate * 1.5m * (Hours - 160);
    }
    class SalariedEmployee : Employee
    {
        public decimal MonthlySalary { get; }
        public SalariedEmployee(string n, decimal salary) : base(n) { MonthlySalary = salary; }
        public override decimal CalculateSalary() => MonthlySalary;
    }
    class CommissionEmployee : Employee
    {
        public decimal Sales { get; } public decimal Rate { get; }
        public CommissionEmployee(string n, decimal sales, decimal rate) : base(n) { Sales = sales; Rate = rate; }
        public override decimal CalculateSalary() => Sales * Rate;
    }
    static class T
    {
        public static void Run()
        {
            var staff = new List<Employee>
            {
                new HourlyEmployee("Игорь", 500, 170),
                new SalariedEmployee("Мария", 90000),
                new CommissionEmployee("Сергей", 400000, 0.10m),
                new HourlyEmployee("Наталья", 450, 120)
            };
            foreach (var e in staff) Console.WriteLine($"{e.Name,-8} ({e.GetType().Name}): {e.CalculateSalary():F2}");
            Console.WriteLine($"Общий фонд зарплаты: {staff.Sum(e => e.CalculateSalary()):F2}");
        }
    }
}

namespace Task29
{
    class Animal { public virtual void MakeSound() => Console.WriteLine("..."); }
    class Dog : Animal { public override void MakeSound() => Console.WriteLine("Собака: Гав!"); }
    class Cat : Animal { public override void MakeSound() => Console.WriteLine("Кошка: Мяу!"); }
    class Cow : Animal { public override void MakeSound() => Console.WriteLine("Корова: Му-у!"); }
    class Duck : Animal { public override void MakeSound() => Console.WriteLine("Утка: Кря!"); }
    class Pig : Animal { public override void MakeSound() => Console.WriteLine("Свинья: Хрю!"); }
    static class T
    {
        public static void Run()
        {
            List<Animal> animals = new List<Animal> { new Dog(), new Cat(), new Cow(), new Duck(), new Pig() };
            foreach (Animal a in animals) a.MakeSound();
        }
    }
}

namespace Task30
{
    abstract class Vehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int MaxSpeed { get; set; }
        public decimal Price { get; set; }

        protected Vehicle(string brand, string model, int year, int maxSpeed, decimal price)
        { Brand = brand; Model = model; Year = year; MaxSpeed = maxSpeed; Price = price; }

        public abstract double FuelPer100Km { get; }
        public virtual string FuelUnit => "л";
        public virtual string Type => "Транспорт";

        public double CalculateFuel(double km) => FuelPer100Km * km / 100.0;

        public virtual void ShowInfo() =>
            Console.WriteLine($"[{Type}] {Brand} {Model}, {Year} г., {MaxSpeed} км/ч, {Price:N0} ₽, расход {FuelPer100Km} {FuelUnit}/100 км");
    }
    class Car : Vehicle
    {
        public int Doors { get; set; }
        public Car(string b, string m, int y, int speed, decimal price, int doors) : base(b, m, y, speed, price) { Doors = doors; }
        public override double FuelPer100Km => 8.0;
        public override string Type => "Легковой";
        public override void ShowInfo() { base.ShowInfo(); Console.WriteLine($"    дверей: {Doors}"); }
    }
    class Truck : Vehicle
    {
        public double CapacityTons { get; set; }
        public Truck(string b, string m, int y, int speed, decimal price, double cap) : base(b, m, y, speed, price) { CapacityTons = cap; }
        public override double FuelPer100Km => 25.0 + CapacityTons * 1.5;
        public override string Type => "Грузовик";
        public override void ShowInfo() { base.ShowInfo(); Console.WriteLine($"    грузоподъёмность: {CapacityTons} т"); }
    }
    class Bus : Vehicle
    {
        public int Seats { get; set; }
        public Bus(string b, string m, int y, int speed, decimal price, int seats) : base(b, m, y, speed, price) { Seats = seats; }
        public override double FuelPer100Km => 18.0 + Seats * 0.1;
        public override string Type => "Автобус";
        public override void ShowInfo() { base.ShowInfo(); Console.WriteLine($"    мест: {Seats}"); }
    }
    class ElectricCar : Vehicle
    {
        public double BatteryKwh { get; set; }
        public ElectricCar(string b, string m, int y, int speed, decimal price, double battery) : base(b, m, y, speed, price) { BatteryKwh = battery; }
        public override double FuelPer100Km => 16.0;
        public override string FuelUnit => "кВт·ч";
        public override string Type => "Электромобиль";
        public override void ShowInfo() { base.ShowInfo(); Console.WriteLine($"    батарея: {BatteryKwh} кВт·ч, запас хода ≈ {BatteryKwh / FuelPer100Km * 100:F0} км"); }
    }
    class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }
        public Motorcycle(string b, string m, int y, int speed, decimal price, bool sidecar) : base(b, m, y, speed, price) { HasSidecar = sidecar; }
        public override double FuelPer100Km => HasSidecar ? 6.5 : 4.5;
        public override string Type => "Мотоцикл";
        public override void ShowInfo() { base.ShowInfo(); Console.WriteLine($"    коляска: {(HasSidecar ? "есть" : "нет")}"); }
    }

    class Fleet
    {
        private readonly List<Vehicle> _vehicles = new List<Vehicle>();

        public void Add(Vehicle v) { _vehicles.Add(v); Console.WriteLine($"+ Добавлен: {v.Brand} {v.Model}"); }

        public bool Remove(string brand, string model)
        {
            Vehicle? v = _vehicles.FirstOrDefault(x => x.Brand == brand && x.Model == model);
            if (v == null) { Console.WriteLine($"! {brand} {model} не найден"); return false; }
            _vehicles.Remove(v);
            Console.WriteLine($"- Удалён: {brand} {model}");
            return true;
        }

        public void ShowAll()
        {
            Console.WriteLine($"--- Автопарк ({_vehicles.Count} ед.) ---");
            foreach (Vehicle v in _vehicles) v.ShowInfo();
        }

        public void ShowFuelReport(double km)
        {
            Console.WriteLine($"--- Расход на {km} км ---");
            foreach (Vehicle v in _vehicles)
                Console.WriteLine($"{v.Brand} {v.Model}: {v.CalculateFuel(km):F1} {v.FuelUnit}");
        }

        public Vehicle? FindFastest() => _vehicles.OrderByDescending(v => v.MaxSpeed).FirstOrDefault();
        public Vehicle? FindMostExpensive() => _vehicles.OrderByDescending(v => v.Price).FirstOrDefault();
    }

    static class T
    {
        public static void Run()
        {
            var fleet = new Fleet();
            fleet.Add(new Car("Toyota", "Camry", 2022, 210, 3_200_000m, 4));
            fleet.Add(new Truck("KAMAZ", "5490", 2021, 110, 6_500_000m, 20));
            fleet.Add(new Bus("Volgabus", "5270", 2020, 100, 9_800_000m, 45));
            fleet.Add(new ElectricCar("Tesla", "Model S", 2023, 250, 11_000_000m, 100));
            fleet.Add(new Motorcycle("Ural", "Gear Up", 2022, 120, 1_100_000m, true));

            fleet.ShowAll();
            fleet.ShowFuelReport(300);

            Console.WriteLine();
            fleet.FindFastest()?.ShowInfo();
            fleet.FindMostExpensive()?.ShowInfo();

            Console.WriteLine();
            fleet.Remove("KAMAZ", "5490");
            fleet.Remove("Lada", "Vesta");
            fleet.ShowAll();
        }
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        var tasks = new (string Title, Action Run)[]
        {
            ("1. Животное", Task01.T.Run), ("2. Транспорт", Task02.T.Run), ("3. Человек и студент", Task03.T.Run),
            ("4. Сотрудники", Task04.T.Run), ("5. Фигуры", Task05.T.Run), ("6. Транспорт с методом движения", Task06.T.Run),
            ("7. Работник магазина", Task07.T.Run), ("8. Компьютеры", Task08.T.Run), ("9. Книги", Task09.T.Run),
            ("10. Домашние животные", Task10.T.Run), ("11. Банковские счета", Task11.T.Run), ("12. Транспортная компания", Task12.T.Run),
            ("13. Работники компании", Task13.T.Run), ("14. Система образования", Task14.T.Run), ("15. Военная техника", Task15.T.Run),
            ("16. Игровые персонажи", Task16.T.Run), ("17. Электронные устройства", Task17.T.Run), ("18. Платежи", Task18.T.Run),
            ("19. Сотрудники с бонусами", Task19.T.Run), ("20. Животные зоопарка", Task20.T.Run),
            ("21. Абстрактные фигуры", Task21.T.Run), ("22. Интернет-магазин", Task22.T.Run), ("23. Система транспорта", Task23.T.Run),
            ("24. Больница", Task24.T.Run), ("25. Person → Employee → Manager → Director", Task25.T.Run), ("26. Игра: персонажи", Task26.T.Run),
            ("27. Файлы", Task27.T.Run), ("28. Система оплаты зарплаты", Task28.T.Run), ("29. Полиморфизм + наследование", Task29.T.Run),
            ("30. Итоговое задание — автопарк", Task30.T.Run),
        };

        foreach (var (title, run) in tasks)
        {
            Console.WriteLine($"\n=========== {title} ===========");
            run();
        }
    }
}